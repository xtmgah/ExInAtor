args<-commandArgs(TRUE)
filter_ex=as.numeric(args[1])
filter_bg=as.numeric(args[2])
GENOMES=as.numeric(args[3])
print(getwd())

# 1) Read data and asigns column names
data=read.table("counts.txt", header=F,row.names=1)
colnames(data)=c("exon_mutations","exon_length","background_mutations","background_length")
data$exon_length=data$exon_length*GENOMES
data$background_length=data$background_length*GENOMES
data<- subset(data, background_mutations >= filter_bg)
data<- subset(data, exon_mutations >= filter_ex)
data$exon_length=data$exon_length-data$exon_mutations
data$background_length=data$background_length-data$background_mutations
data$pval=as.matrix(apply(data,1,function(x){phyper(x[1]-1,x[2],x[4],x[3]+x[1], lower.tail=FALSE)}))

# 2) Apply statistics and order the results

data2=data
data2$qval=as.matrix(p.adjust(data2$pval,method="BH"))
data2=data2[ order(data2[,6], data2[,1]), ]
data3=data2[ order(data2[,5], data2[,1]), ]

data3$color[data3$qval>0.2] <- "black"
data3$color[data3$qval<=0.2] <- "purple"
data3$color[data3$qval<=0.1] <- "blue"
data3$color[data3$qval<=0.01] <- "green"
data3$color[data3$qval<=0.001] <- "gold"
data3$color[data3$qval<=0.0001] <- "red"

png(filename="qqplot.png",width = 800, height = 800, units = "px")
par(mar=c(4.1, 4.7, 4.1, 15.1), xpd=FALSE)
plot(-log10(seq(1,length(data3$pval))/length(data3$pval)),-log10(data3$pval),xlab="Expected Pvalues",ylab="Observed Pvalues",col=data3$color,pch="o",main=paste(" QQplot - ",length(data3$color)," genes",sep=""),cex.lab = 2,cex.axis = 2,cex.main = 2,las=1,cex=2)
abline(0,1)
data4=head(data3,25)
legend("topleft",title="Qval Cutoffs",legend=c(">0.2","<=0.2","<=0.1","<=0.01","<=0.001","<=0.0001"),col=c("Black","Purple","Blue","Green","Gold","Red"), xjust = 1, yjust = 1,pch="o",cex = 2)
a=legend("topright",inset=c(-0.4,0),legend = row.names(data4), xpd=TRUE, bty = 'n',text.col=unlist(data4$color),cex=1.7)
garbage <- dev.off()

# 4) Print final results
print(paste(length(which(data2$qval <= 1))," ",length(which(data2$qval <= 0.1))," ",length(which(data2$qval <= 0.01))," ",length(which(data2$qval <= 0.001))," ",length(which(data2$qval <= 0.0001))," ",sum(data2$exon_mutations)," ",sum(data2$exon_length)," ",sum(data2$background_mutations)," ",sum(data2$background_length)," ",GENOMES))
write.table(data2,file="ExInAtor_Gene_List.txt")
