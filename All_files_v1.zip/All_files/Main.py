#!/usr/bin/python

import regex as re
import sys
import os
import time
import multiprocessing as mp
import random
from math import *
import os.path
import subprocess

start_time = time.time()
seed_number=135
random.seed(seed_number)

# Example command: python2.7 Main.py -i /home/andres/All_files/Inputs/Breast.bed -o /home/andres/All_files/Outputs -f /home/andres/All_files/Inputs/Genome_v19.fasta -g /home/andres/All_files/Inputs/gencode.v19.long_noncoding_RNAs.gtf -s /home/andres/All_files/Inputs/chromosomes.txt -k /home/andres/All_files/Inputs/3mers.txt -w /home/andres/All_files/Inputs/gencode.v19.annotation.gtf -c 6 -n 119 -b 10000

if len(sys.argv)==1 or "-h" in sys.argv: 
	print "Mandatory arguments: -i <--input_file> -o <--output_folder> -f <--fasta_file> -g <--gtf_file> -s <--chr_sizes> -k <--kmers_file> -w <--whole_genome> -n <--number_of_genomes>"
	sys.exit()
n=1
while n<len(sys.argv):
	arg = sys.argv[n]
	if arg == "-i" or arg == "--input_file":
		input_file = sys.argv[n+1]
	elif arg == "-o" or arg == "--output_folder":
		output_folder = sys.argv[n+1]
	elif arg == "-f" or arg == "--fasta_file":
		fasta_file = sys.argv[n+1]
	elif arg == "-g" or arg == "--gtf_file":
		gtf_file = sys.argv[n+1]
	elif arg == "-s" or arg == "--chr_sizes":
		chr_sizes = sys.argv[n+1]
	elif arg == "-k" or arg == "--kmers_file":
		kmers_file = sys.argv[n+1]
	elif arg == "-w" or arg == "--whole_genome":
		whole_genome = sys.argv[n+1]
	elif arg == "-b" or arg == "--background_size":
		background_size = sys.argv[n+1]
	elif arg == "-n" or arg == "--number_of_genomes":
		number_of_genomes = sys.argv[n+1]
	elif arg == "-c" or arg == "--cores":
		cores = int(sys.argv[n+1])
	elif arg == "-e" or arg == "--exonic_filter":
		exonic_filter = sys.argv[n+1]
	elif arg == "-x" or arg == "--background_filter":
		background_filter = sys.argv[n+1]	
	n+=2
if 'input_file' not in globals():
	print "Please indicate \"-i\" or \"--input_file\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'output_folder' not in globals():
	print "Please indicate \"-o\" or \"--output_folder\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'fasta_file' not in globals():
	print "Please indicate \"-f\" or \"--fasta_file\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'gtf_file' not in globals():
	print "Please indicate \"-g\" or \"--gtf_file\""
	print "type \"v1.py -h\" for help"
	sys.exit()
if 'chr_sizes' not in globals():
	print "Please indicate \"-s\" or \"--chr_sizes\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'kmers_file' not in globals():
	print "Please indicate \"-k\" or \"--kmers_file\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'whole_genome' not in globals():
	print "Please indicate \"-w\" or \"--whole_genome\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'number_of_genomes' not in globals():
	print "Please indicate \"-n\" or \"--number_of_genomes\""
	print "type \"Main.py -h\" for help"
	sys.exit()
if 'background_size' not in globals():
	background_size=str(10000)
if 'cores' not in globals():
	cores=1
if 'exonic_filter' not in globals():
	exonic_filter=str(1)
if 'background_filter' not in globals():
	background_filter=str(1)

print("Arguments correctly inserted: %.0f seconds " % (time.time() - start_time))
del arg

print("Starting the analysis of "+input_file.split(".")[0]+": %.0f seconds " % (time.time() - start_time))

if not os.path.exists(output_folder):
	os.makedirs(output_folder)
input_folder=os.getcwd()+"/"
os.chdir(output_folder)
try:
	# Get genes

	genes=[]
	file = open ("genes.bed","r")
	for line in file:
		line=line.rstrip()
		line=line.split("\t")
		genes.append(line[3])

	print("\tGenes gathered: %.0f seconds " % (time.time() - start_time))

	# Get kmers

	file = open (kmers_file,"r")

	kmers=[]
	for line in file:
		line=line.rstrip()
		kmers.append(line)
	file.close()

	print("\tKmers gathered: %.0f seconds " % (time.time() - start_time))

except: adsada=12

if not os.path.isfile("table_kmer_counts.txt"):
		
	# Create a BED file of the merged exons, introns and background for each lncRNA gene.
	subprocess.call("cat "+whole_genome+' | tr --delete \; | tr --delete \\" | grep -v \\# | awk \'$3==\"exon\"\' | awk \'{split($10,array,\".\")}{print $10\"\t\"$4-1\"\t\"$5\"\t\"$1\"\t.\t\"$7}\'  > exons_n2.bed', shell=True)
	subprocess.call("mergeBed -s -i exons_n2.bed -nms | awk \'{split($4,array,\",\")} {print array[1]\"\t\"$2\"\t\"$3\"\t\"$1\"\t\"$5\"\t\"$6}\'> merged_exons_n2.bed", shell=True)
	subprocess.call("cat "+gtf_file+' | tr --delete \; | tr --delete \\" | grep -v \\# | awk \'$3==\"exon\"\' | awk \'{split($10,array,\".\")}{print $10\"\t\"$4-1\"\t\"$5\"\t\"$1\"\t.\t\"$7}\'  > exons_n.bed', shell=True)
	subprocess.call("mergeBed -s -i exons_n.bed -nms | awk \'{split($4,array,\",\")} {print array[1]\"\t\"$2\"\t\"$3\"\t\"$1\"\t\"$5\"\t\"$6}\'> merged_exons_n.bed", shell=True)
	subprocess.call("cat "+gtf_file+' | tr --delete \; | tr --delete \\" | grep -v \\# | awk \'$3==\"gene\"\' | awk \'{print $1\"\t\"$4-1\"\t\"$5\"\t\"$10\"\t.\t\"$7}\'  > genes_n.bed', shell=True)
	subprocess.call("bedtools slop -i genes_n.bed -g "+chr_sizes+" -b "+background_size+" > genes_extended_n.bed", shell=True)
	subprocess.call("subtractBed -a genes_extended_n.bed -b merged_exons_n.bed > introns_n.bed", shell=True)
	subprocess.call("subtractBed -a introns_n.bed -b merged_exons_n2.bed > introns_n2.bed", shell=True)
	subprocess.call('awk \'{split($4,array,\",\")} {print array[1]\"\t\"$2\"\t\"$3\"\t\"$1}\' exons_n.bed | sortBed -i - > exons.bed', shell=True)
	subprocess.call('awk \'{print $1\"\t\"$2\"\t\"$3\"\t\"$4}\' genes_extended_n.bed | sortBed -i - > genes_extended.bed', shell=True)
	subprocess.call('awk \'{print $1\"\t\"$2\"\t\"$3\"\t\"$4}\' genes_n.bed | sortBed -i - > genes.bed', shell=True)
	subprocess.call('awk \'{print $1\"\t\"$2\"\t\"$3\"\t\"$4}\' merged_exons_n.bed | sortBed -i - > merged_exons.bed', shell=True)
	subprocess.call('awk \'{print $1\"\t\"$2\"\t\"$3\"\t\"$4}\' introns_n2.bed | sortBed -i - > introns.bed', shell=True)
	subprocess.call('rm exons_n.bed exons_n2.bed introns_n.bed introns_n2.bed merged_exons_n.bed merged_exons_n2.bed genes_n.bed genes_extended_n.bed', shell=True)

	print("\tBED files created for merged exons and introns: %.0f seconds " % (time.time() - start_time))

	# Count mutation in merged exons and background

	subprocess.call('intersectBed -a merged_exons.bed -b '+input_file+' -sorted -wb | awk \'{print $1"\t"$2-1"\t"$3+1"\t"$4"\t"$5"\t"$6}\' > merged_exons_mutations.bed', shell=True)
	subprocess.call('intersectBed -a introns.bed -b '+input_file+' -sorted -wb | awk \'{print $1"\t"$2-1"\t"$3+1"\t"$4"\t"$5"\t"$6}\' > introns_mutations.bed', shell=True)
	subprocess.call("sed 's/chr//g' merged_exons_mutations.bed > merged_exons_mutations_for_fasta.bed", shell=True)
	subprocess.call("sed 's/chr//g' introns_mutations.bed > introns_mutations_for_fasta.bed", shell=True)
	subprocess.call(' bedtools getfasta -fi '+fasta_file+' -bed merged_exons_mutations_for_fasta.bed -fo merged_exons_mutations.fa -name', shell=True)
	subprocess.call(' bedtools getfasta -fi '+fasta_file+' -bed introns_mutations_for_fasta.bed -fo introns_mutations.fa -name', shell=True)

	print("\tMutations counted in merged exons mutations and introns: %.0f seconds " % (time.time() - start_time))

	# Get genes

	genes=[]
	file = open ("genes.bed","r")
	for line in file:
		line=line.rstrip()
		line=line.split("\t")
		genes.append(line[3])

	print("\tGenes gathered: %.0f seconds " % (time.time() - start_time))

	# Get kmers

	file = open (kmers_file,"r")

	kmers=[]
	for line in file:
		line=line.rstrip()
		kmers.append(line)
	file.close()

	print("\tKmers gathered: %.0f seconds " % (time.time() - start_time))
	
	# Function to count kmers
	
	def count_kmers(list):
		file = open (list[0],"r")
		kmers=list[1]
		order=list[2]
		exons={}
		header = None
		for line in file:
			line=line.rstrip()
			if line.startswith('>'):
				header = line[1:]
			else:
				sequence=line
				if header not in exons:
					exons[header]={}
				for motif in kmers:
					if motif not in exons[header]:
						exons[header][motif]=0
					if motif in exons[header]:
						exons[header][motif]+=len(re.findall(motif, sequence, overlapped=True))
		return((order,exons))
	
	# Function to print the counted kmers
	
	def print_kmers(list):
		file=list[1]
		list=list[0]
		file=open(file,"w")
		for header in list:
			for motif in list[header]:
				line_to_print=header+"\t"+motif+"\t"+str(list[header][motif])+"\n"
				file.write(line_to_print)
		file.close()
		return()
	
	# Function to read the counted kmers
			
	def read_kmers(file_name):
		dir={}
		file=open(file_name,"r")
		for line in file:
			line=line.rstrip()
			line=line.split("\t")
			header=line[0]
			motif=line[1]
			count=line[2]
			if header not in dir:
				dir[header]={}
			if motif not in dir[header]:
				dir[header][motif]=count
		file.close()
		return(dir)
	
	# Calculate or read kmers depending if they have been calculated before or not	
		
	if not os.path.isfile("exonic_kmers.txt"):
		if not os.path.isfile("intronic_kmers.txt"):
			subprocess.call("sed 's/chr//g' merged_exons.bed > merged_exons_for_fasta.bed", shell=True)
			subprocess.call("sed 's/chr//g' introns.bed > introns_for_fasta.bed", shell=True)
			subprocess.call('awk \'{print $1"\t"$2-1"\t"$3+1"\t"$4"\t"$5"\t"$6}\' merged_exons_for_fasta.bed > merged_exons_for_fasta2.bed', shell=True)
			subprocess.call('awk \'{print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}\' introns_for_fasta.bed > introns_for_fasta2.bed', shell=True)		
			subprocess.call('bedtools getfasta -fi '+fasta_file+' -bed merged_exons_for_fasta2.bed -fo merged_exons.fa -name', shell=True)
			subprocess.call('bedtools getfasta -fi '+fasta_file+' -bed introns_for_fasta2.bed -fo introns.fa -name', shell=True)
			os.remove("merged_exons_for_fasta.bed")
			os.remove("introns_for_fasta.bed")
			pool = mp.Pool(processes=cores)
			results = pool.map(count_kmers, [["introns.fa",kmers,2],["merged_exons.fa",kmers,1],["merged_exons_mutations.fa",kmers,3],["introns_mutations.fa",kmers,4]])
		else:
			subprocess.call("sed 's/chr//g' merged_exons.bed > merged_exons_for_fasta.bed", shell=True)
			subprocess.call('awk \'{print $1"\t"$2-1"\t"$3+1"\t"$4"\t"$5"\t"$6}\' merged_exons_for_fasta.bed > merged_exons_for_fasta2.bed', shell=True)
			subprocess.call('bedtools getfasta -fi '+fasta_file+' -bed merged_exons_for_fasta2.bed -fo merged_exons.fa -name', shell=True)
			os.remove("merged_exons_for_fasta.bed")
			pool = mp.Pool(processes=cores)
			results = pool.map(count_kmers, [["merged_exons.fa",kmers,1],["merged_exons_mutations.fa",kmers,3],["introns_mutations.fa",kmers,4]])
			introns=read_kmers("intronic_kmers.txt")
	else:
		if not os.path.isfile("intronic_kmers.txt"):
			subprocess.call("sed 's/chr//g' introns.bed > introns_for_fasta.bed", shell=True)
			subprocess.call('awk \'{print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}\' introns_for_fasta.bed > introns_for_fasta2.bed', shell=True)		
			subprocess.call('bedtools getfasta -fi '+fasta_file+' -bed introns_for_fasta2.bed -fo introns.fa -name', shell=True)
			os.remove("introns_for_fasta.bed")
			pool = mp.Pool(processes=cores)
			results = pool.map(count_kmers, [["introns.fa",kmers,2],["merged_exons_mutations.fa",kmers,3],["introns_mutations.fa",kmers,4]])
			exons=read_kmers("exonic_kmers.txt")
		else:
			pool = mp.Pool(processes=cores)
			results = pool.map(count_kmers, [["merged_exons_mutations.fa",kmers,3],["introns_mutations.fa",kmers,4]])
			exons=read_kmers("exonic_kmers.txt")
			introns=read_kmers("intronic_kmers.txt")
				
	for element in results:
		if element[0]==1: exons=element[1]
		if element[0]==2: introns=element[1]
		if element[0]==3: exons_mutations=element[1]
		if element[0]==4: introns_mutations=element[1]
				
	if not os.path.isfile("exonic_kmers.txt"):
		if not os.path.isfile("intronic_kmers.txt"):
			pool = mp.Pool(processes=cores)
			variable = pool.map(print_kmers, [[exons,"exonic_kmers.txt"],[introns,"intronic_kmers.txt"]])
		else:
			print_kmers(exons,"exonic_kmers.txt")
	else:
		if not os.path.isfile("intronic_kmers.txt"):
			print_kmers(introns,"intronic_kmers.txt")
			

	print("\tKmers counted: %.0f seconds " % (time.time() - start_time))

	# Combine all the information before subsampling

	file=open("table_kmer_counts.txt","w")

	for gene in genes:
		for motif in kmers:
			if gene not in exons:
				a="0"
				b="0"
			if gene in exons:
				if motif not in exons[gene]:
					a="0"
					b="0"
				if motif in exons[gene]:
					b=str(exons[gene][motif])
					if gene not in exons_mutations:
						a="0"
					if gene in exons_mutations:
						if motif in exons_mutations[gene]:
							a=str(exons_mutations[gene][motif])
						if motif not in exons_mutations[gene]:
							a="0"
			if gene not in introns:
				c="0"
				d="0"
			if gene in introns:
				if motif not in introns[gene]:
					c="0"
					d="0"
				if motif in introns[gene]:
					d=str(introns[gene][motif])
					if gene not in introns_mutations:
						c="0"
					if gene in introns_mutations:
						if motif in introns_mutations[gene]:
							c=str(introns_mutations[gene][motif])
						if motif not in introns_mutations[gene]:
							c="0"
			line_to_print=gene+"\t"+motif+"\t"+a+"\t"+b+"\t"+c+"\t"+d+"\n"
			file.write(line_to_print)
				
	file.close()
		
	print("\tAll information combined: %.0f seconds " % (time.time() - start_time))
	del results, exons, introns, exons_mutations, introns_mutations
	subprocess.call('cp table_kmer_counts.txt table_kmer_counts_backup.txt', shell=True)
	subprocess.call('grep -v -P "\.\t" table_kmer_counts_backup.txt > table_kmer_counts.txt', shell=True)
	subprocess.call('rm table_kmer_counts_backup.txt', shell=True)
if not os.path.isfile("counts.txt"):
	# Get all the information before subsampling

	file=open("table_kmer_counts.txt","r")

	table_kmer_counts={}
	for line in file:
		line=line.rstrip()
		line=line.split("\t")
		gene=line[0]
		motif=line[1]
		ex_mut=int(line[2])
		ex_len=int(line[3])
		in_mut=int(line[4])
		in_len=int(line[5])
		tot_mut=ex_mut+in_mut
		tot_len=ex_len+in_len
		if gene not in table_kmer_counts:
			table_kmer_counts[gene]={}
		table_kmer_counts[gene][motif]=[ex_mut,ex_len,in_mut,in_len]
	file.close()

	for gene in table_kmer_counts:
		total=0.0
		for motif in table_kmer_counts[gene]:
			total+=table_kmer_counts[gene][motif][1]
		table_kmer_counts[gene]["Total"]=total

	print("\tTable_kamer_count.txt parsed: %.0f seconds " % (time.time() - start_time))

	# Function to subsample the background region

	def define(gene):
		random.seed(seed_number)
		try:
			if "ENSGR" not in gene:
				if gene in table_kmer_counts:
					gene=str(gene)
					exons_counts={}
					introns_counts={}
					eyes=0
					eno=table_kmer_counts[gene]["Total"]
					iyes=0
					ino=0
					for nuc in kmers:
						im=int(table_kmer_counts[gene][nuc][2])
						it=int(table_kmer_counts[gene][nuc][3]-im)
						if nuc not in introns_counts: introns_counts[nuc]=[]
						introns_counts[nuc].extend([nuc+"+"]*im)
						introns_counts[nuc].extend([nuc+"-"]*it)
						eyes+=table_kmer_counts[gene][nuc][0]
						if nuc not in exons_counts: exons_counts[nuc]=0
						exons_counts[nuc]=int(round(float(table_kmer_counts[gene][nuc][1])/float(table_kmer_counts[gene]["Total"])*1000.0))

					for nuc in kmers:
						random.shuffle(introns_counts[nuc])

					llllllist=[]
					for nuc in kmers:
						if exons_counts[nuc]>0:
							a_number=(len(introns_counts[nuc])-(len(introns_counts[nuc])%exons_counts[nuc]))/exons_counts[nuc]
							llllllist.append(a_number)
					min_number=min(llllllist)
					
					for nuc in kmers:
						if exons_counts[nuc]>0:
							found=len(filter(lambda x:'+' in x, introns_counts[nuc][:exons_counts[nuc]*min_number]))
							iyes+=found
							ino+=int(exons_counts[nuc]*min_number)
						
					return((gene,eyes,eno,iyes,ino))
		except: dadadsr=0

	file2=open("counts.txt","w")
	pool = mp.Pool(processes=cores)
	results = pool.map(define, genes)	
	for element in results:
		if element is not None:
			line=str(element[0].split(".")[0])+"\t"+str(element[1])+"\t"+str(int(element[2]))+"\t"+str(element[3])+"\t"+str(element[4])+"\n"
			file2.write(line)
	print("\tCounts calculated: %.0f seconds " % (time.time() - start_time))       		
	file2.close()	

	try: subprocess.call('rm introns_for_fasta2.bed merged_exons.fa merged_exons_for_fasta2.bed introns.fa exons.bed genes_extended.bed introns.bed introns_mutations.bed introns_mutations.fa introns_mutations_for_fasta.bed merged_exons_mutations_for_fasta.bed merged_exons_mutations.fa merged_exons_mutations.bed merged_exons.bed', shell=True)
	except: dadadsr=0

# Execute statistics with R			
subprocess.call('Rscript '+input_folder+'Stats.r '+exonic_filter+" "+background_filter+" "+number_of_genomes, shell=True)

print("\tQvalues calculated: %.0f seconds " % (time.time() - start_time))
